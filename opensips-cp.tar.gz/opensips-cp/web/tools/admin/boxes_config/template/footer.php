</td>
 </tr>
</table>
</center>
</body>

</html>
<?php
 // $_SESSION['current_tool']="boxes_config";
 // $_SESSION['user_active_page']=$page_name;
?>
