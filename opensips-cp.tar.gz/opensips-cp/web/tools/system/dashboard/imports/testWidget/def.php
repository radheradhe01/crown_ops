<?php

$widget_def = array(
    "info" => "Test widget",
    "description" => "Widget that tests",
    "json" => "{\"widget_type\":\"cdr_widget\", \"widget_title\":\"Import test\",\"widget_name\":\"Import test\"}"
);

?>