  </td>
 </tr>
</table>
</center>
</body>

</html>
<?php
 $_SESSION['user_active_page']=$page_name;
?>